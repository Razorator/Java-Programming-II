import java.util.ArrayList;

public class Pipe<T> {
    private ArrayList<T> pipes;

    public Pipe() {
        pipes = new ArrayList<>();
    }

    public void putIntoPipe(T value) {
        pipes.add(value);
    }

    public T takeFromPipe() {
        if (pipes.isEmpty()) {
            return null;
        }
        T returned = pipes.get(0);
        pipes.remove(0);
        return returned;
    }

    public boolean isInPipe() {
        if (!pipes.isEmpty()) {
            return true;
        }
        return false;
    }
}
