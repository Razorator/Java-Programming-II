import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.stream.Collectors;

public class Hand implements Comparable<Hand> {
    private ArrayList<Card> cards;

    public Hand() {
        cards = new ArrayList<>();
    }

    public void add(Card card) {
        cards.add(card);
    }

    public void print() {
        cards.stream()
                .forEach(System.out::println);
    }

    public void sort() {
        this.cards = (ArrayList<Card>) cards.stream()
                .sorted((x,y) -> x.compareTo(y))
                .collect(Collectors.toList());
    }

    public void sortBySuit() {
        Collections.sort(cards, new BySuitInValueOrder());
    }

    public int compareTo(Hand hand) {
        int thisValue = 0;
        int thatValue = 0;
        thisValue = this.cards.stream()
                .mapToInt(x -> x.getValue())
                .sum();

        thatValue = hand.cards.stream()
                .mapToInt(x -> x.getValue())
                .sum();
        return thisValue - thatValue;
    }
}
