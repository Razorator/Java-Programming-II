

public class Main {

    public static void main(String[] args) {
        Suitcase x = new Suitcase(20);
        Item carrot = new Item("carrot", 1);
        Item carrot2 = new Item("carrot", 1);
        Item zebra = new Item("zebra", 15);

        x.addItem(carrot);
        x.addItem(carrot2);
        x.addItem(zebra);

        x.printItems();

    }

}
