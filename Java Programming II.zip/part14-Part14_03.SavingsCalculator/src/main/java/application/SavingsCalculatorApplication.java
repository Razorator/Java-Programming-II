package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;



public class SavingsCalculatorApplication extends Application {

    public static void main(String[] args) {

        launch(SavingsCalculatorApplication.class);
    }

    public static XYChart.Series calculateMonthlySavings(double slider1) {
        XYChart.Series savings = new XYChart.Series();
        for (int i = 0; i < 31; i++) {
            savings.getData().add(new XYChart.Data(i, (slider1 * 12 * i)));
        }
        return savings;
    }

    public static XYChart.Series calculateWithInterest(double slider1, double slider2) {
        XYChart.Series savings = new XYChart.Series();
        double total = 0;
        for (int i = 0; i <= 30; i++) {
            total = 0;
            for (int y = 0; y <= i; y++) {
                if (y == i) {
                    savings.getData().add(new XYChart.Data(i, total));
                }
                total = (total + slider1 * 12) * ((100 + slider2) / 100);
            }
        }
        return savings;
    }

    @Override
    public void start(Stage stage) {
        BorderPane border = new BorderPane();

        NumberAxis xAxis = new NumberAxis(0, 30, 4);
        NumberAxis yAxis = new NumberAxis();
        xAxis.setTickUnit(1);

        LineChart chart = new LineChart(xAxis, yAxis);
        border.setCenter(chart);

        VBox vbox = new VBox();
        BorderPane pane1 = new BorderPane();
        BorderPane pane2 = new BorderPane();

        Label label11 = new Label("Monthly savings");
        Slider slider1 = new Slider();
        Label label12 = new Label();
        //set position
        pane1.setLeft(label11);
        pane1.setCenter(slider1);
        pane1.setRight(label12);

        Label label21 = new Label("Yearly interest rate");
        Slider slider2 = new Slider();
        Label label22 = new Label();
        //set position
        pane2.setLeft(label21);
        pane2.setCenter(slider2);
        pane2.setRight(label22);

        slider1.setShowTickLabels(true);
        slider1.setShowTickMarks(true);
        slider1.setMin(25);
        slider1.setMax(250);
        slider2.setShowTickLabels(true);
        slider2.setShowTickMarks(true);
        slider2.setMin(0);
        slider2.setMax(10);

        label12.setText(String.valueOf(slider1.getValue()));
        label22.setText(String.valueOf(slider2.getValue()));

        XYChart.Series monthlySavings = calculateMonthlySavings(slider1.getValue());
        monthlySavings.setName("Monthly savings");
        chart.getData().add(monthlySavings);

        XYChart.Series monthlyWithInterest = calculateWithInterest(slider1.getValue(), slider2.getValue());
        monthlyWithInterest.setName("With interest");
        chart.getData().add(monthlyWithInterest);

        slider1.setOnMouseReleased(event -> {
            monthlySavings.setData(calculateMonthlySavings(slider1.getValue()).getData());
            monthlyWithInterest.setData(calculateWithInterest(slider1.getValue(), slider2.getValue()).getData());
            label12.setText(String.valueOf(slider1.getValue()));
            label22.setText(String.valueOf(slider2.getValue()));
        });

        slider2.setOnMouseReleased(event -> {
            monthlySavings.setData(calculateMonthlySavings(slider1.getValue()).getData());
            monthlyWithInterest.setData(calculateWithInterest(slider1.getValue(), slider2.getValue()).getData());
            label12.setText(String.valueOf(slider1.getValue()));
            label22.setText(String.valueOf(slider2.getValue()));
        });

        vbox.getChildren().addAll(pane1, pane2);
        border.setTop(vbox);

        Scene scene = new Scene(border);
        stage.setScene(scene);
        stage.show();
    }
}
