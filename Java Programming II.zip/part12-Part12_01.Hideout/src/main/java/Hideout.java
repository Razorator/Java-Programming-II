public class Hideout<T> {
    private T hide;

    public void putIntoHideout(T toHide) {
        hide = toHide;
    }

    public T takeFromHideout() {
        T toReturn = hide;
        hide = null;
        return toReturn;
    }

    public boolean isInHideout() {
        if (hide != null) {
            return true;
        }
        return false;
    }
}
