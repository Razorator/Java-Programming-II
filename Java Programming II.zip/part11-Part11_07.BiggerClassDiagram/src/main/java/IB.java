public interface IB {
}
