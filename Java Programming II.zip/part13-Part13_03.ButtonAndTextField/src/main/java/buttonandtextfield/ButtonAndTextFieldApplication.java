package buttonandtextfield;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.FlowPane;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ButtonAndTextFieldApplication extends Application {


    public static void main(String[] args) {
        launch(ButtonAndTextFieldApplication.class);
    }

    @Override
    public void start(Stage stage) throws Exception {
        Button button = new Button("Press me Im a button");
        TextField field = new TextField("text field");
        FlowPane pane = new FlowPane();

        pane.getChildren().add(button);
        pane.getChildren().add(field);

        Scene scene = new Scene(pane);

        stage.setScene(scene);
        stage.show();
    }
}
