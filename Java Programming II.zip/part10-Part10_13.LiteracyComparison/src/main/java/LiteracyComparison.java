
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

public class LiteracyComparison {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> rows = new ArrayList<>();
        try {
            Files.lines(Paths.get("literacy.csv"))
                    .forEach(x -> rows.add(x));
        } catch (Exception e) {
    }
        rows.stream()
                .map(row -> row.split(","))
                .sorted((x, y) -> {return (x[5].compareTo(y[5]));})
                .map(x -> x[3] + " (" + x[4] + "), " + x[2].split(" ")[1] + ", " + x[5])
                .forEach(System.out::println);
}
}
