public class Person implements Saveable {
    private String name;
    private String address;

    public void save(){

    }

    public void delete(){

    }

    public void load(String address){

    }
}
