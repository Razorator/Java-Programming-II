package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class JokeApplication extends Application {


    public static void main(String[] args) {
        launch(JokeApplication.class);
    }

    public void start(Stage window) {
        BorderPane layout = new BorderPane();

        Button joke = new Button("Joke");
        joke.setMinWidth(100);
        Button answer = new Button("Answer");
        answer.setMinWidth(100);
        Button explanation = new Button("Explanation");
        explanation.setMinWidth(100);
        HBox tabs = new HBox(joke, answer, explanation);
        tabs.setSpacing(10);

        Label jokeText = new Label("What do you call a bear with no teeth?");
        Label answerText = new Label("A gummy bear.");
        Label explanationText = new Label("Ovo je vic objasnjenje");



        layout.setTop(tabs);
        layout.setCenter(jokeText);

        Scene whole = new Scene(layout);

        joke.setOnAction(actionEvent -> {
            layout.setCenter(jokeText);
        });
        answer.setOnAction(actionEvent -> {
            layout.setCenter(answerText);
        });
        explanation.setOnAction(actionEvent -> {
            layout.setCenter(explanationText);
        });
        window.setScene(whole);
        window.show();
    }
}
