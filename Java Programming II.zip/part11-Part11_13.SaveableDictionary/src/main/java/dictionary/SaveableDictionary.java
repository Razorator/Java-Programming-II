package dictionary;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class SaveableDictionary {
    private Map<String,String> dictionary;
    private String file;

    public SaveableDictionary() {
        dictionary = new HashMap<>();
    }

    public SaveableDictionary(String file) {
        dictionary = new HashMap<>();
        this.file = file;
    }

    public boolean load() {
        ArrayList<String> fileRead = new ArrayList<>();
        try {
            Files.lines(Paths.get(file)).forEach(x -> fileRead.add(x));
        } catch (Exception e) {
            return false;
        }
        for (String each : fileRead) {
            String[] likeThis = each.split(":");
            dictionary.put(likeThis[0], likeThis[1]);
        }
        return true;
    }

    public boolean save() {
            File toWrite = new File(String.valueOf(Paths.get(file)));
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        }
        for (String key : dictionary.keySet()) {
                    writer.println(key + ":" + dictionary.get(key));
                }
            writer.close();
        return true;
    }

    public void add(String words, String translation) {
        if (dictionary.get(words) != null) {
            return;
        }
        dictionary.put(words, translation);
    }


    public String translate(String word) {
        if (dictionary.get(word) != null) {
            return dictionary.get(word);
        }
        for (String key : dictionary.keySet()) {
                if (Objects.equals(dictionary.get(key), word)) {
                    return key;
                }
        }
        return null;
    }

    public void delete(String word) {
        if (dictionary.get(word) != null) {
            dictionary.remove(word);
        }
        for (String key : dictionary.keySet()) {
            if (Objects.equals(dictionary.get(key), word)) {
                dictionary.remove(key);
                break;
            }
        }
    }
}
