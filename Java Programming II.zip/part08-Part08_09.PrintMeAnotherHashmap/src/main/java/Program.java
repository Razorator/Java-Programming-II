
import java.util.ArrayList;
import java.util.HashMap;

public class Program {

    public static void printValues(HashMap<String, Book> hashmap) {
        for (String each : hashmap.keySet()) {
            System.out.println("Name: " + hashmap.get(each).getName() + " (" + hashmap.get(each).getPublicationYear() + ")");
            System.out.println("Contents: " + hashmap.get(each).getContents());
        }
    }

    public static void printValueIfNameContains(HashMap<String, Book> hashmap, String text) {
        for (String each : hashmap.keySet()) {
            if (!(hashmap.get(each).getName().contains(text))) {
                continue;
            }
            System.out.println("Name: " + hashmap.get(each).getName() + " (" + hashmap.get(each).getPublicationYear() + ")");
            System.out.println("Contents: " + hashmap.get(each).getContents());
        }
    }

    public static void main(String[] args) {
        HashMap<String, Book> hashmap = new HashMap<>();
        hashmap.put("sense", new Book("Sense and Sensibility", 1811, "..."));
        hashmap.put("prejudice", new Book("Pride and prejudice", 1813, "...."));

        printValues(hashmap);
        System.out.println("---");
        printValueIfNameContains(hashmap, "prejud");
    }

}
