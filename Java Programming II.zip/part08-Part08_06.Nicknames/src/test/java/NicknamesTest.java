
import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.*;

@Points("08-06")
public class NicknamesTest {

    @Test
    public void noTests() throws Exception {
        // no tests

    }

}
