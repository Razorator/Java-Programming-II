package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class GreeterApplication extends Application {


    public static void main(String[] args) {
        launch(GreeterApplication.class);
    }

    @Override
    public void start(Stage window){
        Label intro = new Label("Enter your name and start.");
        TextField name = new TextField();
        Button start = new Button("Start");
        GridPane grid = new GridPane();
        grid.add(intro, 0, 0);
        grid.add(name, 0, 1);
        grid.add(start, 0, 2);
        Scene first = new Scene(grid);

        String x = "";

        start.setOnAction((actionEvent -> {
            Label welcome = new Label("Welcome " + name.getText() + "!");
            Scene second = new Scene(welcome);
            window.setScene(second);
                })
        );

        window.setScene(first);
        window.show();

    }
}
