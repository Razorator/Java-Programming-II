

public class MainProgram {

    public static void main(String[] args) {
        Checker check = new Checker();

        System.out.println(check.timeOfDay("23:49:59")); //true
        System.out.println(check.timeOfDay("25:49:59")); //false
        System.out.println(check.timeOfDay("11:23:01")); //true
        System.out.println(check.timeOfDay("01:01:01")); //true

    }
}
