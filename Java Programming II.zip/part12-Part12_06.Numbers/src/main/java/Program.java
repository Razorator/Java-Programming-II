
import java.util.Random;
import java.util.Scanner;

public class Program {

    public static void main(String[] args) {
        Random randomizer = new Random();
        Scanner scanner = new Scanner(System.in);
        System.out.println("How many random numbers should be printed?");
        int times = Integer.valueOf(scanner.nextLine());
        for (int i = 0; i < times; i++) {
            System.out.println(randomizer.nextInt(11));
        }
    }

}
