import java.util.HashMap;

public class IOU {
    private HashMap<String,Double> map;
    
    public IOU() {
        map = new HashMap<>();
    }
    
    public void setSum(String toWhom, double amount) {
        map.put(toWhom,amount);
    }
    
    public double howMuchDoIOweTo(String toWhom) {
        if (map.containsKey(toWhom)) {
        return (map.get(toWhom));
        }
        return 0;
    }
}
