public class Plane {
    private String ID;
    private String model;
    private int yearOfIntroduction;
}
