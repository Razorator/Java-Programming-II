package application;

import java.util.ArrayList;
import java.util.List;

public class AverageSensor implements Sensor {
    private ArrayList<Sensor> sensors;
    private List<Integer> list;

    public void addSensor(Sensor toAdd) {
        if (sensors == null && list == null) {
            sensors = new ArrayList<>();
            list = new ArrayList<>();
        }
        sensors.add(toAdd);
    }

    public List<Integer> readings() {
        return list;
    }

    public boolean isOn() {
        for (int i = 0; i < sensors.size(); i++) {
            if (sensors.get(i).isOn() == false) {
                return false;
            }
        }
        return true;
    }

    public void setOn() {
        for (int i = 0; i < sensors.size(); i++) {
            sensors.get(i).setOn();
        }
    }

    public void setOff() {
        for (int i = 0; i < sensors.size(); i++) {
            sensors.get(i).setOff();
        }
    }

    public int read() {
        if (!(this.isOn()) || sensors.isEmpty()) {
            throw new IllegalStateException("Average sensor off or empty");
        }
        int total = 0;
        for (Sensor sensor : sensors) {
            total += sensor.read();
        }
        int average = (total / sensors.size());
        list.add(average);
        return average;
    }
}
