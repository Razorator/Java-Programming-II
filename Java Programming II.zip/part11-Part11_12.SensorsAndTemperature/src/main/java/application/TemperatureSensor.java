package application;
import java.util.Random;
import java.lang.Math;

public class TemperatureSensor implements Sensor {
    private boolean state;

    public TemperatureSensor() {
        state = false;
    }

    public boolean isOn() {
        return state;
    }

    public void setOn() {
        state = true;
    }

    public void setOff() {
        state = false;
    }

    public int read() {
        if (isOn()) {
            return new Random().nextInt(61) - 30;
        }
        throw new IllegalStateException("Is off");
    }
}
