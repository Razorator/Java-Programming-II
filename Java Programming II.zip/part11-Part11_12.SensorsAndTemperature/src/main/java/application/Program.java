package application;

public class Program {

    public static void main(String[] args) {
        Sensor kumpula = new StandardSensor(4);
        Sensor kaisaniemi = new StandardSensor(5);
        Sensor helsinkiVantaaAirport = new StandardSensor(9);

        AverageSensor helsinkiRegion = new AverageSensor();
        helsinkiRegion.addSensor(kumpula);
        helsinkiRegion.addSensor(kaisaniemi);
        helsinkiRegion.addSensor(helsinkiVantaaAirport);

        helsinkiRegion.setOn();
        System.out.println("temperature in Helsinki region " + helsinkiRegion.read() + " degrees Celsius");
        System.out.println("temperature in Helsinki region " + helsinkiRegion.read() + " degrees Celsius");
        System.out.println("temperature in Helsinki region " + helsinkiRegion.read() + " degrees Celsius");

        System.out.println("readings: " + helsinkiRegion.readings());

        System.out.println("Average: " + helsinkiRegion.read());
    }
}
