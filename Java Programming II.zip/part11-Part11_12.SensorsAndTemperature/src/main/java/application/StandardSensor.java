package application;

public class StandardSensor implements Sensor{
    private int given;

    public StandardSensor(int give) {
        given = give;
    }

    public boolean isOn() {
        return true;
    }

    public void setOn() {

    }

    public void setOff() {

    }

    public int read() {
        return given;
    }
}
