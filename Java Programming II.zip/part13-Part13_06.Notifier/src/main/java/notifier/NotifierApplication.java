package notifier;


import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.awt.*;

public class NotifierApplication extends Application {


    public static void main(String[] args) {

        System.out.println("Hello world!");
        launch(NotifierApplication.class);
    }


    @Override
    public void start(Stage stage) {
        TextField topmost = new TextField();
        Button middle = new Button("Update");
        Label bottom = new Label();
        VBox box = new VBox();
        middle.setOnAction((actionEvent ->  {
            bottom.setText(topmost.getText());
        }));
        box.getChildren().addAll(topmost, middle, bottom);
        Scene scene = new Scene(box);

        stage.setScene(scene);
        stage.show();
    }
}
