
import java.util.ArrayList;

public class ChangeHistory {

    private ArrayList<Double> changes;

    public ChangeHistory() {
        changes = new ArrayList<>();
    }

    public void add(double status) {
        changes.add(status);
    }

    public void clear() {
        changes.clear();
    }

    public double average() {
        if (changes.isEmpty()) {
            return 0;
        }
        int count = 0;
        double sum = 0;
        for (Double each : changes) {
            count++;
            sum = sum + each;
        }
        return sum/count;
    }
    
    public double minValue() {
        double min = changes.get(0);
        for (Double each : changes) {
            if (each < min) {
                min = each;
            }
        }
        return min;
    }

    public double maxValue() {
        double max = 0;
        for (Double each : changes) {
            if (each > max) {
                max = each;
            }
        }
        return max;
    }

    public String toString() {
        return changes.toString();
    }
}
