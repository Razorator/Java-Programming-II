package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class MultipleViews extends Application {

    public static void main(String[] args) {

        launch(MultipleViews.class);

    }

    @Override
    public void start(Stage window) {
        BorderPane pane = new BorderPane();
        Label first = new Label("First view!");
        Button toSecond = new Button("To the second view!");
        pane.setTop(first);
        pane.setCenter(toSecond);

        VBox vbox = new VBox();
        Button toThird =  new Button("To the third view!");
        Label second = new Label("Second view!");
        vbox.getChildren().add(toThird);
        vbox.getChildren().add(second);


        GridPane grid = new GridPane();
        Label text = new Label("Third view!");
        Button toFirst = new Button("To the first view!");
        grid.add(text, 0, 0);
        grid.add(toFirst, 1, 1);

        Scene firstScene = new Scene(pane);
        Scene secondScene = new Scene(vbox);
        Scene thirdScene = new Scene(grid);

        toThird.setOnAction((event) -> {
            window.setScene(thirdScene);
        });

        toSecond.setOnAction((event) -> {
            window.setScene(secondScene);
        });

        toFirst.setOnAction((event) -> {
            window.setScene(firstScene);
        });

        window.setScene(firstScene);
        window.show();
    }

}
