
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class MainProgram {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Book> books = new ArrayList<>();

        while (true) {
            System.out.print("Input the name of the book, empty stops: ");
            String input = scanner.nextLine();
            if (input.equals("")) {
                break;
            }
            System.out.print("Input the age recommendation: ");
            int input2 = Integer.valueOf(scanner.nextLine());
            books.add(new Book(input, input2));
        }
        System.out.println();
        System.out.println(books.size() + " books in total.");
        System.out.println();
        System.out.println("Books:");
        Comparator<Book> compare = Comparator
                .comparing(Book::getAge)
                .thenComparing(Book::getName);

        Collections.sort(books, compare);
        books.stream()
                .forEach(System.out::println);
    }

    public static class Book {
        String name;
        int age;
        Book(String name, int age) {
            this.name = name;
            this.age = age;
        }

        int getAge() {
            return age;
        }

        String getName() {
            return name;
        }
        public String toString() {
            return name + " (recommended for " + age + " year-olds or older)";
        }
    }

}
