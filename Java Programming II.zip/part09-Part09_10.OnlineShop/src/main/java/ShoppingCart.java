import java.util.List;
import java.util.ArrayList;

public class ShoppingCart {
    private List<Item> items;

    public ShoppingCart() {
        items = new ArrayList<>();
    }

    public void add(String product, int price) {
        for (Item each : items) {
            String[] check = each.toString().split(":");
            if (check[0].equals(product)) {
                each.increaseQuantity();
                return;
            }
        }
        items.add(new Item(product, 1, price));
    }

    public int price() {
        int price = 0;
        for (Item each : items)
            price = price + each.price();
        return price;
        }

    public void print() {
        for (Item each : items) {
            System.out.println(each);
        }
    }
}
