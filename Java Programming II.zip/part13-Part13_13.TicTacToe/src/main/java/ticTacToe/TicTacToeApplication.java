package ticTacToe;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;


public class TicTacToeApplication extends Application {

    public boolean whoseTurn = true;
    public boolean end = false;

    public static void main(String[] args) {
        launch(TicTacToeApplication.class);
    }

    @Override
    public void start(Stage window) {


        BorderPane layout = new BorderPane();


        Label turnText = new Label("Turn: X");
        turnText.setFont(new Font(25));
        layout.setTop(turnText);


        GridPane buttons = new GridPane();

        for (int i = 0; i<3; i++) {
            for (int y = 0; y<3; y++) {
                Button btn = new Button(" ");
                int row = y;
                int col = i;
                btn.setFont(Font.font("Monospaced", 40));
                btn.setOnAction(event -> {
                    if (btn.getText() == " " && !end) {

                        if (whoseTurn) {
                            btn.setText("X");
                        } else {
                            btn.setText("O");
                        }
                        whoseTurn = !whoseTurn;
                        if (whoseTurn) {
                            turnText.setText("Turn: X");
                            buttons.getChildren().get(row*3+col).setAccessibleText("X");
                        } else {
                            turnText.setText("Turn: O");
                            buttons.getChildren().get(row*3+col).setAccessibleText("O");
                        }
                    }
                    for (int x = 0; x < 3; x++) {
                        if (buttons.getChildren().get(x).getAccessibleText() != (null)) {
                            if (buttons.getChildren().get(x).getAccessibleText() == (buttons.getChildren().get(x + 3).getAccessibleText())
                                    && buttons.getChildren().get(x).getAccessibleText() == (buttons.getChildren().get(x + 6).getAccessibleText())) {
                                turnText.setText("The end!");
                                end = true;
                                break;
                            }
                        }

                        if (buttons.getChildren().get(x).getAccessibleText() != (null)) {
                            if (buttons.getChildren().get(x).getAccessibleText() == (buttons.getChildren().get(x + 1).getAccessibleText())
                                    && buttons.getChildren().get(x).getAccessibleText() == (buttons.getChildren().get(x + 2).getAccessibleText())) {
                                turnText.setText("The end!");
                                end = true;
                                break;
                            }
                        }

                        if (buttons.getChildren().get(0).getAccessibleText() != (null)) {
                            if (buttons.getChildren().get(0).getAccessibleText() == (buttons.getChildren().get(4).getAccessibleText())
                                    && buttons.getChildren().get(0).getAccessibleText() == (buttons.getChildren().get(8).getAccessibleText())) {
                                turnText.setText("The end!");
                                end = true;
                                break;
                            }
                        }

                        if (buttons.getChildren().get(2).getAccessibleText() != (null)) {
                            if (buttons.getChildren().get(2).getAccessibleText() == (buttons.getChildren().get(4).getAccessibleText())
                                    && buttons.getChildren().get(2).getAccessibleText() == (buttons.getChildren().get(6).getAccessibleText())) {
                                turnText.setText("The end!");
                                end = true;
                                break;
                            }
                        }
                    }
                });
                buttons.add(btn, i, y);
            }
        }

        buttons.setHgap(10);
        buttons.setVgap(10);
        layout.setCenter(buttons);
        layout.setPadding(new Insets(10, 10, 10, 10));

        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.show();

    }
}
