package ticTacToe;

import javafx.scene.text.Font;

public class Button extends javafx.scene.control.Button {
    private boolean pressed;
    private boolean turnX;

    public Button() {
        this.setText(" ");
        this.pressed = false;
        this.turnX = true;
        setFont(Font.font("Monospaced", 40));
        setOnAction(event -> {
            if (turnX) {
                press("X");
            } else {
                press("O");
            }
        });

    }

    public boolean assigned() {
        return pressed;
    }

    public void press(String who) {
        this.pressed = true;
        this.setText(who);
    }

}
