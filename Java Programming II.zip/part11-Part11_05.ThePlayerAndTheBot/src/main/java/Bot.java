public class Bot extends Player {

    @Override
    public void play(){

    }

    public void addMove(String move) {

    }
}
