package title;

import javafx.stage.Stage;
import javafx.application.Application;

public class UserTitle extends Application {

    @Override
    public void start(Stage stage) {
        Parameters params = getParameters();
        String name = params.getNamed().get("name");

        stage.setTitle(name);


        stage.show();
    }

}
