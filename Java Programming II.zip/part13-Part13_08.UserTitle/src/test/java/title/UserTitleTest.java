package title;

import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.*;

@Points("13-08")
public class UserTitleTest {

    @Test
    public void noTests() {

    }

}
