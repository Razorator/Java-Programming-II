import java.util.ArrayList;

public class Box implements Packable {
    private double capacity;
    private ArrayList<Packable> items;

    public Box(double max) {
        capacity = max;
        items = new ArrayList<>();
    }

    public void add(Packable item) {
        if (item.weight() + this.weight() <= capacity) {
            items.add(item);
        }
    }
    public double weight() {
        double weight = 0;
        for (Packable each : items) {
            weight = weight + each.weight();
        }
        return weight;
    }

    public String toString() {
        return "Box: " + items.size() + " items, total weight " + weight() + " kg";
    }
}
