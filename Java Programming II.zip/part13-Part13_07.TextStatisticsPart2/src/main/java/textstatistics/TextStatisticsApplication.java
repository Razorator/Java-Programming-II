package textstatistics;
import javafx.application.Application;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.BorderPane;

import java.util.Arrays;

public class TextStatisticsApplication extends Application {


    public static void main(String[] args) {

        launch(TextStatisticsApplication.class);
    }


    @Override
    public void start(Stage stage) throws Exception {
        BorderPane pane = new BorderPane();
        TextArea textArea = new TextArea();
        pane.setCenter(textArea);

            HBox box = new HBox();
            box.setSpacing(10);

        Label first = new Label("Letters: 0");
        Label second = new Label("Words: 0");
        Label third = new Label("The longest word is:");

        box.getChildren().add(first);
        box.getChildren().add(second);
        box.getChildren().add(third);

        pane.setBottom(box);

        textArea.textProperty().addListener((change, oldValue, newValue) -> {
            int letters = newValue.length();
            String[] parts = newValue.split(" ");
            int words = parts.length;
            String longest = Arrays.stream(parts)
                    .sorted((y, x) -> x.length() - y.length())
                    .findFirst()
                    .get();
            box.getChildren().set(0, new Label("Letters: " + letters));
            box.getChildren().set(1, new Label("Words: " + words));
            box.getChildren().set(2, new Label("The longest word is: " + longest));

        });

        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
    }
}
