package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;

import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PartiesApplication extends Application {

    public static void main(String[] args) {

        launch(PartiesApplication.class);
    }

    public static List<String> read(String file) {
        List<String> rows = new ArrayList<>();

        try {
            Files.lines(Paths.get(file)).forEach(row -> rows.add(row));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return rows;
    }

    @Override
    public void start(Stage stage) {
        Scanner scanner = new Scanner(System.in);

        NumberAxis xAxis = new NumberAxis(1968, 2008, 4);
        NumberAxis yAxis = new NumberAxis();

        xAxis.setLabel("Year");
        yAxis.setLabel("Percentage");

        LineChart chart = new LineChart(xAxis, yAxis);

        List<String> rows = read("partiesdata.tsv");
        String[] years = rows.get(0).split("\t");
        System.out.println(years[0]);
        for (int i = 1; i < rows.size(); i++) {
            String[] each = rows.get(i).split("\t");
            XYChart.Series data = new XYChart.Series();
            data.setName(each[0]);
            for (int y = 1; y < each.length; y++) {
                if ((each[y]).equals("-")) {
                    continue;
                }
                data.getData().add(new XYChart.Data(Integer.valueOf(years[y]), Double.valueOf(each[y])));
                if (y == each.length - 1) {
                    chart.getData().add(data);
                }
            }
        }

        Scene scene = new Scene(chart);
        stage.setScene(scene);
        stage.show();

        
    }

}
