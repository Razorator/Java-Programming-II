
public class MagicSquareFactory {

    public MagicSquare createMagicSquare(int size) {
        if (size % 2 == 0) {
            size++;
        }
        MagicSquare square = new MagicSquare(size);
        int x = size/2;
        int y = 0;
        int value = 1;
        while (value < size * size) {
            square.placeValue(x,y,value);
            value++;
            if (y-1 < 0) {
                y = size - 1;
            } else {
                y--;
            }
            if (x+1 > size - 1) {
                x = 0;
            } else {
                x++;
            }
            while (square.readValue(x,y) != 0) {
                if (x == size-1 && y == 0) {
                    y++;
                    break;
                }
                if (y + 2 > size - 1) {
                    y = 0;
                } else {
                    y = y + 2;
                }
                if (x-1 < 0) {
                    x = size -1;
                } else {
                    x--;
                }
            }
        }
        square.placeValue(size/2, size-1, size*size);

        return square;
    }

}
