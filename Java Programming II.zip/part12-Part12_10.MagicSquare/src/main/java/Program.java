
public class Program {

    public static void main(String[] args) {
        // Test the MagicSquare class here
        
        MagicSquareFactory msFactory = new MagicSquareFactory();
        System.out.println(msFactory.createMagicSquare(9));


        MagicSquare square = new MagicSquare(2);
        square.placeValue(0,0,1);
        square.placeValue(0,1,2);
        square.placeValue(1,0,3);
        square.placeValue(1,1,4);

        MagicSquare square2 = new MagicSquare(3);
        square2.placeValue(0,0,1);
        square2.placeValue(0,1,2);
        square2.placeValue(0,2,3);
        square2.placeValue(1,0,4);
        square2.placeValue(1,1,5);
        square2.placeValue(1,2,6);
        square2.placeValue(2,0,7);
        square2.placeValue(2,1,8);
        square2.placeValue(2,2,9);

        System.out.println(square.sumsOfColumns());
        System.out.println(square.sumsOfRows());

        System.out.println(square2.sumsOfColumns());
        System.out.println(square2.sumsOfRows());
    }
}
