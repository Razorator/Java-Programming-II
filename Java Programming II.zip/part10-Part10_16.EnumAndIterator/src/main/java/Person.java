public class Person {
    private String name;
    private Education edu;

    public Person(String name, Education ed) {
        this.name = name;
        edu = ed;
    }

    public Education getEducation() {
        return edu;
    }

    @Override
    public String toString() {
        StringBuilder returned = new StringBuilder();
        returned.append(name).append(", ").append(getEducation());
        return returned.toString();
    }

}
