public class Show {
    private String movie;
    private String time;
}
