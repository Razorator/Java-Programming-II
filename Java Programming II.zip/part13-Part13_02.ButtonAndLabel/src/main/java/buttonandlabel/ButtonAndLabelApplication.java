package buttonandlabel;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;


public class ButtonAndLabelApplication extends Application {


    public static void main(String[] args) {
        launch(ButtonAndLabelApplication.class);
    }

    @Override
    public void start(Stage stage) throws Exception {
        Button button = new Button("Press me Im a button");
        Label label = new Label("I'm not a button but text");

        FlowPane pane = new FlowPane();

        pane.getChildren().add(label);
        pane.getChildren().add(button);

        Scene scene = new Scene(pane);

        stage.setScene(scene);
        stage.show();
    }
}
