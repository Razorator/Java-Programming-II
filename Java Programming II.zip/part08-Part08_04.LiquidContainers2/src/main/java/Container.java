
public class Container {

    private int contains = 0;

    public Container() {

    }

    public int contains() {
        return contains;
    }

    public void add(int amount) {
        if (amount > 0) {
            contains = contains + amount;
            if (contains > 100) {
                contains = 100;
            }
        }
    }

    public void remove(int amount) {
        contains = contains - amount;
        if (contains < 0) {
            contains = 0;
        }
    }

    public String toString() {
        return contains + "/100";
    }
}
