package smiley;


import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class SmileyApplication extends Application {


    public static void main(String[] args) {
        launch(SmileyApplication.class);
    }

    @Override
    public void start(Stage stage) {
        Canvas canvas = new Canvas(640, 480);
        GraphicsContext painter = canvas.getGraphicsContext2D();

        BorderPane paintingLayout = new BorderPane();
        paintingLayout.setCenter(canvas);
            double xLocation = 200;
            double yLocation = 100;
            painter.setFill(Color.BLACK);
            painter.fillRect(250, 100, 50, 50);
            painter.fillRect(390, 100, 50, 50);
            painter.fillRect(200, 250, 50, 50);
            painter.fillRect(440, 250, 50, 50);
            painter.fillRect(390, 300, 50, 50);
            painter.fillRect(340, 300, 50, 50);
            painter.fillRect(290, 300, 50, 50);
            painter.fillRect(250, 300, 50, 50);


        Scene scene = new Scene(paintingLayout);
        stage.setScene(scene);
        stage.show();
    }
}
