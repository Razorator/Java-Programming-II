
import java.util.Scanner;

public class LiquidContainers {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int first = 0;
        int second = 0;

        while (true) {
            System.out.println("First: " + first + "/100");
            System.out.println("Second: " + second + "/100");

            String input = scan.nextLine();
            String[] words = input.split(" ");
            if (input.equals("quit")) {
                break;
            }
            if (words[0].equals("add")) {
                int amount = Integer.valueOf(words[1]);
                for (int i = 0; i < amount; i++) {
                    if (first < 100) {
                        first++;
                    }
                }
            }
            if (words[0].equals("move")) {
                int actualAmount = 0;
                int amount = Integer.valueOf(words[1]);
                for (int i = 0; i < amount; i++) {
                    if (first > 0) {
                        first--;
                        actualAmount++;
                    }
                }
                for (int i = 0; i < actualAmount; i++) {
                    if (second < 100) {
                        second++;
                    }
                }
            }
            if (words[0].equals("remove")) {
                int amount = Integer.valueOf(words[1]);
                for (int i = 0; i < amount; i++) {
                    if (second > 0) {
                        second--;
                    }
                }
            }
            System.out.println("");

        }
    }

}
