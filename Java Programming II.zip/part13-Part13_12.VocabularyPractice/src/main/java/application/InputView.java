package application;

import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

public class InputView {

    private Dictionary dictionary;

    public InputView(Dictionary dictionary) {
        this.dictionary = dictionary;
    }

    public Parent getView(){
        GridPane addPage = new GridPane();

        Label wordLabel = new Label("Enter a word:");
        Label translLabel = new Label("Enter the translation:");
        TextField wordField = new TextField();
        TextField translField = new TextField();
        Button addButton = new Button("Add the word pair");
        Label addInfo = new Label();

        addPage.add(wordLabel, 0, 0);
        addPage.add(wordField, 1, 0);
        addPage.add(translLabel, 0, 1);
        addPage.add(translField, 1, 1);
        addPage.add(addButton, 0, 2);
        addPage.add(addInfo, 1, 2);

        addPage.setHgap(10);
        addPage.setVgap(10);
        addPage.setPadding(new Insets(30, 30, 30, 30));

        addButton.setOnMouseClicked((event) -> {
            String word = wordField.getText();
            String translation = translField.getText();

            if (!translField.getText().isEmpty() && !wordField.getText().isEmpty()) {
                dictionary.add(word, translation);
                addInfo.setText("Translation added successfully!");
                wordField.clear();
                translField.clear();
            } else {
                addInfo.setText("Input text in both fields");
            }
        });

        return addPage;
    }
}
