package application;

import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

public class PracticeView {
    private Dictionary dictionary;

    public PracticeView(Dictionary dictionary) {
        this.dictionary = dictionary;
    }

    public Parent getView() {
        Label translate = new Label("Translate the word ");
        TextField enterTranslation = new TextField();
        VBox practiceView = new VBox();
        Button check = new Button("Check");
        practiceView.getChildren().addAll(translate, enterTranslation, check);

        return practiceView;
    }
}
