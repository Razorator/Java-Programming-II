package application;


import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;




// END SOLUTION
public class VocabularyPracticeApplication extends Application {

    private Dictionary dictionary;

    public void init() throws Exception {
        this.dictionary = new Dictionary();
    }
    public static void main(String[] args) {
        launch(VocabularyPracticeApplication.class);
    }

    @Override
    public void start(Stage window) throws Exception {
        InputView inputView = new InputView(dictionary);
        PracticeView practiceView = new PracticeView(dictionary);

        // add translation tab + practice tab
        HBox tabs = new HBox();
        Button addTab = new Button("Enter new words");
        Button practiceTab = new Button("Practice");
        tabs.getChildren().setAll(addTab, practiceTab);

        // add word and translation page


        // practice view


        // whole window


        VBox whole = new VBox();

        whole.getChildren().addAll(tabs, inputView.getView());

        Scene first = new Scene(whole);


        window.setScene(first);
        window.show();

        addTab.setOnAction(event -> {
            whole.getChildren().setAll(tabs, inputView.getView());
        });
        practiceTab.setOnAction(event -> {
            whole.getChildren().setAll(tabs, practiceView.getView());
        });


    }
}
