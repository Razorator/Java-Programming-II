
public class Main {

    public static void main(String[] args) {
        C c = new C();

        c.a();
        c.b();
        c.c();
    }
}
