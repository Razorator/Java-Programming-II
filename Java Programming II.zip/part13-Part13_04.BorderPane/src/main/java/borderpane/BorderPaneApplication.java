package borderpane;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.Label;

public class BorderPaneApplication extends Application {


    public static void main(String[] args) {
        launch(BorderPaneApplication.class);
    }

    @Override
    public void start(Stage stage) {
        BorderPane pane = new BorderPane();
        Label north = new Label("NORTH");
        Label south = new Label("SOUTH");
        Label east = new Label("EAST");
        pane.setTop(north);
        pane.setBottom(south);
        pane.setRight(east);

        Scene scene = new Scene(pane);

        stage.setScene(scene);
        stage.show();


    }
}
